1. Supabase > SQL Editor: cole schema.sql e rode.
2. Supabase > Auth > URL Configuration: coloque a Redirect URL usada em www/config.js.
3. Edite www/config.js (URL e anon key).
4. Suba tudo no GitHub (branch main). Actions > Build APK > baixe o artefato app-debug.apk.
