-- Rode SOMENTE este arquivo (seu schema anterior ja foi aplicado)
alter table restaurants add column if not exists phone text, add column if not exists address text, add column if not exists doc text;
