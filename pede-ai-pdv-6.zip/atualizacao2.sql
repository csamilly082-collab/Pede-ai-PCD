-- Rode este arquivo UMA vez no SQL Editor (depois do schema.sql e atualizacao.sql)
create table ingredients(id uuid primary key default gen_random_uuid(), restaurant_id uuid not null references restaurants on delete cascade, name text not null, unit text not null default 'un', stock numeric not null default 0, min_stock numeric not null default 0, cost_cents int, created_at timestamptz default now());
create table inventory_movements(id uuid primary key, restaurant_id uuid not null references restaurants on delete cascade, ingredient_id uuid not null references ingredients on delete cascade, qty numeric not null, reason text not null, order_id uuid, created_at timestamptz default now());
create table recipe_items(id uuid primary key default gen_random_uuid(), restaurant_id uuid not null references restaurants on delete cascade, product_id uuid not null references products on delete cascade, ingredient_id uuid not null references ingredients on delete cascade, qty numeric not null check(qty>0), unique(product_id,ingredient_id));
create table customer_transactions(id uuid primary key, restaurant_id uuid not null references restaurants on delete cascade, customer_id uuid not null references customers on delete cascade, amount_cents int not null, reason text not null, order_id uuid, created_at timestamptz default now());
create table drivers(id uuid primary key default gen_random_uuid(), restaurant_id uuid not null references restaurants on delete cascade, name text not null, phone text, active boolean not null default true);
alter table orders add column if not exists is_delivery boolean not null default false, add column if not exists delivery_address text, add column if not exists delivery_status text check(delivery_status in('awaiting','assigned','out','delivered')), add column if not exists driver_id uuid references drivers;
create index on inventory_movements(ingredient_id); create index on customer_transactions(customer_id);
create function apply_stock() returns trigger language plpgsql security definer set search_path=public as $$ begin update ingredients set stock=stock+new.qty where id=new.ingredient_id and restaurant_id=new.restaurant_id; return new; end $$;
create trigger t_stock after insert on inventory_movements for each row execute function apply_stock();
create function apply_balance() returns trigger language plpgsql security definer set search_path=public as $$ begin update customers set balance_cents=balance_cents+new.amount_cents where id=new.customer_id and restaurant_id=new.restaurant_id; return new; end $$;
create trigger t_balance after insert on customer_transactions for each row execute function apply_balance();
do $$ declare t text; begin
 foreach t in array array['ingredients','recipe_items','drivers'] loop
  execute format('alter table %I enable row level security',t);
  execute format('create policy %I on %I for all using(is_member(restaurant_id)) with check(is_member(restaurant_id))',t||'_all',t);
 end loop;
 foreach t in array array['inventory_movements','customer_transactions'] loop
  execute format('alter table %I enable row level security',t);
  execute format('create policy %I on %I for select using(is_member(restaurant_id))',t||'_sel',t);
  execute format('create policy %I on %I for insert with check(is_member(restaurant_id))',t||'_ins',t);
 end loop; end $$;
