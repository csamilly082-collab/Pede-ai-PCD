-- Rode UMA vez no SQL Editor (fotos e categorias dos produtos)
alter table products add column if not exists image text;
do $$ declare c text; begin
 select conname into c from pg_constraint where conrelid='products'::regclass and contype='f' and confrelid='categories'::regclass;
 if c is not null then execute format('alter table products drop constraint %I',c); end if;
 alter table products add constraint products_category_fk foreign key(category_id) references categories on delete set null;
end $$;
