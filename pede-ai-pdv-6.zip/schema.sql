-- PEDE AÍ PDV — cole tudo no Supabase > SQL Editor > Run
create extension if not exists pgcrypto;
create table restaurants(id uuid primary key default gen_random_uuid(), name text not null, owner_id uuid default auth.uid() references auth.users, pix_key_type text, pix_key text, pix_name text, pix_city text, created_at timestamptz default now());
create table members(restaurant_id uuid references restaurants on delete cascade, user_id uuid references auth.users on delete cascade, role text not null default 'staff' check(role in('owner','staff')), primary key(restaurant_id,user_id));
create table categories(id uuid primary key default gen_random_uuid(), restaurant_id uuid not null references restaurants on delete cascade, name text not null);
create table products(id uuid primary key default gen_random_uuid(), restaurant_id uuid not null references restaurants on delete cascade, category_id uuid references categories, name text not null, description text, price_cents int not null check(price_cents>=0), active boolean default true, created_at timestamptz default now(), updated_at timestamptz default now());
create table customers(id uuid primary key default gen_random_uuid(), restaurant_id uuid not null references restaurants on delete cascade, name text not null, phone text, balance_cents int not null default 0);
create table orders(id uuid primary key, restaurant_id uuid not null references restaurants on delete cascade, status text not null check(status in('open','awaiting_payment','paid','cancelled')), customer_id uuid references customers, subtotal_cents int not null check(subtotal_cents>=0), discount_cents int not null default 0 check(discount_cents>=0), delivery_fee_cents int not null default 0 check(delivery_fee_cents>=0), total_cents int not null check(total_cents>=0), note text, cancel_reason text, created_at timestamptz default now());
create table order_items(id uuid primary key, order_id uuid not null references orders on delete cascade, restaurant_id uuid not null references restaurants on delete cascade, product_id uuid, name text not null, qty int not null check(qty>0), unit_cents int not null check(unit_cents>=0), note text);
create table payments(id uuid primary key, order_id uuid not null references orders on delete cascade, restaurant_id uuid not null references restaurants on delete cascade, method text not null check(method in('pix','credit','debit','cash','balance','other')), amount_cents int not null check(amount_cents>=0), status text not null check(status in('pending','confirmed')), created_at timestamptz default now());
create index on products(restaurant_id); create index on orders(restaurant_id,created_at); create index on order_items(order_id); create index on payments(order_id);

create function is_member(rid uuid) returns boolean language sql security definer stable set search_path=public as $$ select exists(select 1 from members where restaurant_id=rid and user_id=auth.uid()) $$;
create function is_owner(rid uuid) returns boolean language sql security definer stable set search_path=public as $$ select exists(select 1 from members where restaurant_id=rid and user_id=auth.uid() and role='owner') $$;
create function create_restaurant(p_name text) returns uuid language plpgsql security definer set search_path=public as $$
declare r uuid; begin
 if auth.uid() is null then raise exception 'not authenticated'; end if;
 insert into restaurants(name,owner_id) values(p_name,auth.uid()) returning id into r;
 insert into members values(r,auth.uid(),'owner'); return r; end $$;

alter table restaurants enable row level security; alter table members enable row level security;
create policy r_sel on restaurants for select using(is_member(id));
create policy r_upd on restaurants for update using(is_owner(id)) with check(is_owner(id));
create policy m_sel on members for select using(user_id=auth.uid() or is_owner(restaurant_id));
do $$ declare t text; begin
 foreach t in array array['categories','products','customers','orders','order_items','payments'] loop
  execute format('alter table %I enable row level security',t);
  execute format('create policy %I on %I for all using(is_member(restaurant_id)) with check(is_member(restaurant_id))',t||'_all',t);
 end loop; end $$;
-- Edições sensíveis (preço/produto) só para dono:
drop policy products_all on products;
create policy products_sel on products for select using(is_member(restaurant_id));
create policy products_w on products for all using(is_owner(restaurant_id)) with check(is_owner(restaurant_id));
alter table restaurants add column if not exists phone text, add column if not exists address text, add column if not exists doc text;
create table ingredients(id uuid primary key default gen_random_uuid(), restaurant_id uuid not null references restaurants on delete cascade, name text not null, unit text not null default 'un', stock numeric not null default 0, min_stock numeric not null default 0, cost_cents int, created_at timestamptz default now());
create table inventory_movements(id uuid primary key, restaurant_id uuid not null references restaurants on delete cascade, ingredient_id uuid not null references ingredients on delete cascade, qty numeric not null, reason text not null, order_id uuid, created_at timestamptz default now());
create table recipe_items(id uuid primary key default gen_random_uuid(), restaurant_id uuid not null references restaurants on delete cascade, product_id uuid not null references products on delete cascade, ingredient_id uuid not null references ingredients on delete cascade, qty numeric not null check(qty>0), unique(product_id,ingredient_id));
create table customer_transactions(id uuid primary key, restaurant_id uuid not null references restaurants on delete cascade, customer_id uuid not null references customers on delete cascade, amount_cents int not null, reason text not null, order_id uuid, created_at timestamptz default now());
create table drivers(id uuid primary key default gen_random_uuid(), restaurant_id uuid not null references restaurants on delete cascade, name text not null, phone text, active boolean not null default true);
alter table orders add column if not exists is_delivery boolean not null default false, add column if not exists delivery_address text, add column if not exists delivery_status text check(delivery_status in('awaiting','assigned','out','delivered')), add column if not exists driver_id uuid references drivers;
create index on inventory_movements(ingredient_id); create index on customer_transactions(customer_id);
create function apply_stock() returns trigger language plpgsql security definer set search_path=public as $$ begin update ingredients set stock=stock+new.qty where id=new.ingredient_id and restaurant_id=new.restaurant_id; return new; end $$;
create trigger t_stock after insert on inventory_movements for each row execute function apply_stock();
create function apply_balance() returns trigger language plpgsql security definer set search_path=public as $$ begin update customers set balance_cents=balance_cents+new.amount_cents where id=new.customer_id and restaurant_id=new.restaurant_id; return new; end $$;
create trigger t_balance after insert on customer_transactions for each row execute function apply_balance();
do $$ declare t text; begin
 foreach t in array array['ingredients','recipe_items','drivers'] loop
  execute format('alter table %I enable row level security',t);
  execute format('create policy %I on %I for all using(is_member(restaurant_id)) with check(is_member(restaurant_id))',t||'_all',t);
 end loop;
 foreach t in array array['inventory_movements','customer_transactions'] loop
  execute format('alter table %I enable row level security',t);
  execute format('create policy %I on %I for select using(is_member(restaurant_id))',t||'_sel',t);
  execute format('create policy %I on %I for insert with check(is_member(restaurant_id))',t||'_ins',t);
 end loop; end $$;
alter table products add column if not exists image text;
do $$ declare c text; begin
 select conname into c from pg_constraint where conrelid='products'::regclass and contype='f' and confrelid='categories'::regclass;
 if c is not null then execute format('alter table products drop constraint %I',c); end if;
 alter table products add constraint products_category_fk foreign key(category_id) references categories on delete set null;
end $$;
