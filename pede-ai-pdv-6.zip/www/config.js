// Somente chave anon (pública). Nunca coloque a service_role aqui.
window.CFG={url:"https://qbaihzvuuttvmwbdhhge.supabase.co",key:"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFiYWloenZ1dXR0dm13YmRoaGdlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTI2OTUxMzYsImV4cCI6MjEwODI3MTEzNn0.3JCeCKuZL1AKkZ_j3jWXb1wywBXdaVMA--iKRNzGRMo",redirect:"https://localhost"};
