-- Rode UMA vez no SQL Editor (adicionais e funcionarios)
alter table products add column if not exists addons jsonb not null default '[]';
create or replace function add_member(p_email text) returns text language plpgsql security definer set search_path=public as $$
declare r uuid; u uuid; begin
 select restaurant_id into r from members where user_id=auth.uid() and role='owner' limit 1;
 if r is null then raise exception 'apenas o dono pode adicionar funcionarios'; end if;
 select id into u from auth.users where lower(email)=lower(trim(p_email));
 if u is null then raise exception 'usuario nao encontrado: peca para criar a conta no app primeiro'; end if;
 insert into members values(r,u,'staff') on conflict do nothing; return 'ok'; end $$;
